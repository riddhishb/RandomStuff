Riddhish Bhalodia 120070003

 In Question1:

The input is given by an some_name.txt, not hardcoded in the code so it needs to be executed as ./stack some_name.txt
The output will be observed in terminal.

