#include <iostream>
#include <fstream>
#include <cstdlib>

using namespace std;
#include "bst.h"

BinSearchTree* BinSearchTree::buildTree(BinSearchTree *tree, char letter){
  if (tree == NULL) {
    tree = new BinSearchTree (letter); 
  } else { 
/*DO NOT EDIT BEFORE THIS LINE*/
/*Make appropriate changes here to build a BST*/
  }
}
void BinSearchTree::printTreePreOrder (BinSearchTree *temp, std::ofstream &fp1) {
/*Make appropriate changes here*/
}
void BinSearchTree::printTreeInOrder (BinSearchTree *temp, std::ofstream &fp1) {
/*Make appropriate changes here*/
}
