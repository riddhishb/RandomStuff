#include <avr/io.h>
#include <avr/interrupt.h>
#include "lcd.h"
#include <util/delay.h>
#include "lcd.c"


int secondGain = 1;


int main(void)
{
LCD_CONTROL_DDR |= 1<<EN | 1<<RW | 1<<RS;
	_delay_ms(15);
	DDRC |= 1<<PINC0 | 1<<PINC1 ;
	
	Send_A_Command(0x01); //Clear Screen
	_delay_ms(2);
	Send_A_Command(0x38);
	_delay_us(50);
	Send_A_Command(0b00001110);
	_delay_us(50);	


ADCSRA |= 1<<ADPS2;
ADMUX |= 1<<REFS0 | 1<<REFS1;
ADCSRA |= 1<<ADIE;
ADCSRA |= 1<<ADEN;

sei();

ADCSRA |= 1<<ADSC;

while (1)
{
}
}
ISR(ADC_vect)
{
uint8_t theLow = ADCL;
uint16_t theTenBitResult = ADCH<<8 | theLow;

switch (ADMUX)
{
case 0xC0:
Send_A_Command(0x01);
        _delay_ms(2);
        Send_An_Integer(theTenBitResult,4);
        Send_A_String(",");
	//_delay_ms(30);

ADMUX = 0xC1;
break;
case 0xC1:
secondGain = 2;

        _delay_ms(2);
        
        Send_An_Integer(theTenBitResult,4);
  //      Send_A_String(",");
//	_delay_ms(300);
ADMUX = 0xC2;
break;

case 0xC2:
secondGain = 2;
Send_A_Command(0xC0);
        _delay_ms(2);
        
        Send_An_Integer(theTenBitResult,4);
        Send_A_String(",");

//	_delay_ms(300);
ADMUX = 0xC3;
break;

case 0xC3:
secondGain = 2;

        _delay_ms(2);
        
        Send_An_Integer(theTenBitResult,4);
//        Send_A_String(",");

	_delay_ms(300);
ADMUX = 0xC0;
break;
default:
//Default code
break;
}
 ADCSRA |= 1<<ADSC;
}